 
    const { ObjectId } = require('mongodb');
        const db = require('../connection');

        const getAllHys = async function (req, res) {
        let data = await db.get().collection('hys').find().toArray()
        res.render('pages/allhys',{data});
        }

        const getHyAddform = async function (req, res) {
        res.render('forms/addhy');
        }

        const addHy = async function (req, res) {
        let data = req.body
        await db.get().collection('hys').insertOne(data)
        res.render('pages/hy', { data })
        }

        const getHyEditform = async function (req, res) {
        let id = req.params.id
        let data = await db.get().collection('hys').findOne({ _id: ObjectId(id) })
        res.render('forms/edithy', { data });
        }

        const editHy = async function (req, res) {
        let newdata = req.body
        let query = { _id: ObjectId(req.body.id) }
        var newvalues = { $set: { name: newdata.name,} };
        await db.get().collection('hys').updateOne(query, newvalues)
        res.redirect(`/hys/${req.body.id}`)
        }

        const deleteHy = async function (req, res) {
        let id = req.params.id
        await db.get().collection('hys').deleteOne({ _id: ObjectId(id) })
        res.redirect('back')
        }

        const getHyById = async function (req, res) {
        let id = req.params.id
        let data = await db.get().collection('hys').findOne({ _id: ObjectId(id) })
        res.render('pages/hy', { data });
        }

        exports.getAllHys = getAllHys;
        exports.getHyAddform = getHyAddform;
        exports.addHy = addHy;
        exports.getHyEditform = getHyEditform;
        exports.editHy = editHy;
        exports.deleteHy = deleteHy;
        exports.getHyById = getHyById;
    