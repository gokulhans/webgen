
  var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  let data = [{name:"don"},{name:"don"},{name:"don"}]
res.render('index', {[object Object],[object Object],[object Object]});
});



module.exports = router;

  
 
