    
    const express = require("express");
    const router = express.Router();
    const hysController = require("../controllers/hys-controller");

    router.get("/", hysController.getAllHys);
    router.get('/add', hysController.getHyAddform);
    router.post("/add", hysController.addHy);
    router.get('/edit/:id',hysController.getHyEditform);
    router.post("/edit", hysController.editHy);
    router.get('/:id', hysController.getHyById);
    router.get("/delete/:id", hysController.deleteHy);

    module.exports = router;