
  if (process.env.NODE_ENV !== 'production') {
    require('dotenv').config()
  }
  var createError = require('http-errors');
  var express = require('express');
  var path = require('path');
  var cookieParser = require('cookie-parser');
  var logger = require('morgan');
  const sessions = require('express-session');
  var db = require('./connection');
  const hbs = require('express-handlebars');
  var app = express();
  
  db.connect((err) => {
    if (err) console.log("Connection Error" + err);
    else console.log("Database connected to port")
  })


  var indexRouter = require('./routes/index');

  